﻿namespace QuickMarkWeb.Server.Shared.Course
{
    public class CourseDTO
    {
        public string Code { get; set; }
        public string Name { get; set; }
    }
}
